<html>
  <title>
        Cadena y Numeros
  </title>
  <body bgcolor="AntiqueWhite">
     <font face="Goudy Stout" color="Chocolate" size="2">	
	 <?php
	  $Nombre="Lizbeth";
	  $Numero1=16;
	  $Numero2=29;
	  echo "Hola $Nombre <br> ";
	  echo $Numero1+$Numero2;
	  echo"<br>";
	  echo $Numero1-$Numero2;
	 ?>
	 </font>
 </body>
</html>
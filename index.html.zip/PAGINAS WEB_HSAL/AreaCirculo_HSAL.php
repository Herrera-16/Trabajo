<html>
     <title>
	      Area Circulo
	 </title>
    <body bgcolor ="Honeydew">
	   <font face="DarkTurquoise" color="RoyalBlue" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="PaleTurquoise" width="600" height="25"> 
                   Area de un circulo 
             </marquee>
          </div>
       </font> 
	  <center>
	  <font face="Arial" color="DarkTurquoise" size="3">
	      <form method="Get">
		     <br> <br> 
		  Radio del circulo: <input name= "Radio" size="5" type="text"> cm
		     <br> <br> 
          <input value="Calcula área" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
	 	
	 <?php
	 define("PI", 3.1416);
	 if (isset($_GET["Radio"]))
	 { 
	     $radio=$_GET["Radio"];
	  
	 if(is_numeric($radio))
	 { 
	     echo "Area del circulo";  
		 echo PI*PI*$radio; 
		 echo "cm²";
	 } 	   
	   
	 else
	 { 
	     echo "<b> Radio no valido </b> por lo tanto no se puede calcular el area";  
	 } 
     }	 
	 ?>
	 </form>
	 </center>
	</body>
</html>

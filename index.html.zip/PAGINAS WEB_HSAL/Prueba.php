<html>
     <title>
           Prueba 
     </title>
     <body bgcolor="MistyRose">
          <?php
            echo"Este texto se muestra en la página";
               //muestra el texto encerrado entre comillas 
			echo 3+5;
			   /*muestra resultados de algun calculo o muestra valores o contenido de variables*/
			echo date('d/m/Y');
			   //muestra informacion regresada por alguna función
          ?>
     </body>
</html>

<html>
     <title>
	      Mayor Menor
	 </title>
    <body bgcolor ="MistyRose ">
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Mayor o menor de edad 
				</b>
             </marquee>
          </div>
       </font> 
	  <center>
	  <font face="Britannic Bold" color="Crimson" size="3">
	      <form method="Get">
		     <br> <br> 
		  Edad: <input name= "Edad" size="5" type="text"> 
		     <br> <br> 
          <input value="Mayor o menor" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
	 	
	 <?php
	    if(isset($_GET["Edad"]))
		   {
			 $ValorEdad=$_GET["Edad"];
			 
	    if(is_numeric($ValorEdad))
		   {
			   if($ValorEdad>18)
				   {
					 echo"Es mayor de edad";
				   }
			   else
				   {
					echo"Es menor de edad"; 
				   }
	 
	       }
	 	   } 
   	 
	 ?>
	 </form>
	 </center>
	</body>
</html>

<html>
  <title>
        Operadores Relacionales
  </title>
  <body bgcolor="AntiqueWhite">
     <font face="Britannic Bold" color="Bisque" size="4">
        <center>
           <marquee direction="right" bgcolor="SandyBrown" height="30">   
                 Uso de Variables y Operadores Relacionales
           </marquee>
        </center>
     </font>
	 <?php
	 echo "<center>";
	 $a=10;
	 $b=20;
	 $c=30;
	 echo "$a es mayor que $b?";
	 echo $a > $b;
	 echo "<br> <br>";
	 echo "$a es menor que $b?";
	 echo $a < $b;
	 echo "<br> <br>";
	 echo "$a es igual a $b?";
	 echo $a == $b;
	 echo "<br> <br>";
	 echo "$c es mayor o igual que $b?";
	 echo $c >= $b;
	 echo "<br> <br>";
	 echo "$c menor o igual que $b?";
     echo $c <= $b;
     echo "<br> <br>";	
     echo "$c es diferebte a $b?";
     echo $c != $b;	 
     echo "<br> <br>";
	 echo "</center>";
	 ?> 
  </body>
</html>
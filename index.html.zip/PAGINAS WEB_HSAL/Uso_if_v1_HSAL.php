<html>
   <title>
       Uso if 
   </title>
    <body bgcolor ="Honeydew">
	   <font face="DarkTurquoise" color="RoyalBlue" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="PaleTurquoise" width="600" height="25"> 
                   Ejemplo de uso de if
             </marquee>
          </div>
       </font> 
	   <center>
	    <font face="Arial" color="DarkTurquoise" size="3">
	      <form method="Get">
	         <br> <br>
          Proporcione un número entero: <input name= "Numero" size="5" type="text">
		     <br> <br> 
          <input value="Enviar" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 	
		</form>
	</font>
       </center>	
	   <center>
       <?php
	   $Numeroencuesta=$_GET["Numero"];
	   $NumeroPositivo=0;
	   echo "El valor de la variable Num es: "; echo "<b>";  echo $Numeroencuesta; echo "</b>"; echo "<br>"; 
	    if ($Numeroencuesta >= $NumeroPositivo)
		{  
	      echo "Por lo tanto, lo que contiene la variable"; echo "<b>";  echo " es un número positivo"; echo "</b>"; 
	    }    
	   
       ?>	
       </center>	   
	</body> 
</html>
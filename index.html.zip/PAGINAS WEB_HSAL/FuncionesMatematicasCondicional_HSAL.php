<html>
  <head>
   <title>
      Funciones Matematicas
   </title>
  </head>
   <body bgcolor="Azure">
         <center>
	   <font face="Congenial Black" color="Navy" size="4"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Uso de funciones matemáticas   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br>
	  <center>  
	 <form method="GET">
		     <br> <br> 
          Número 1 <input name= "num1" size="5" type="text">
		     <br> <br> 
		  Número 2: <input name= "num2" size="5" type="text">
		     <br> <br>
		  Número 3: <input name= "num3" size="5" type="text">
		     <br> <br>		 
	
	<table border = 2 width="450" height="50" bordercolor= "DarkBlue">
	<tr> <th> Operación </th> <th> Descrpción </th> </tr>
	<tr> <td> 1 </td> <td> <i> Numero 1 <sup> Número 2 </sup> <i> </td> </tr>
	<tr> <td> 2 </td> <td> <i> Raiz Cuadrada del Numero 3 </i> </td> </tr> 
	<tr> <td> 3 </td> <td> <i>  Obtener el maximo de los 3 números </i> </td> </tr> 
	<tr> <td> 4 </td> <td> <i> Obtener el minimo de los 3 números </i> </td> </tr> 
	<tr> <td> 5 </td> <td> <i> Obtener un número aleatorio entre el minimo y el maximo de los 3 números </i> </td> </tr> 
	</table> 

		  <br> <br>
	   <b> Elige un número de operacion que te interese realizar: </b> <input name= "operacion" size="5" type="text">
	      <br> <br>
	       <input value = "Realiza la operacion" type="submit"> 
		</form> 
    </center>
	   <font face="Congenial Black" color="Navy" size="3"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="20"> 
			    <b>
                  ********************* Resultados *********************    
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> 		
	  <center>
	  
	  
		<?php
		
	    if (isset($_GET["num1"]))
	       { 	          
		       $NUMERO1=$_GET["num1"];
				  			  
		if (isset($_GET["num2"]))
			{
		       $NUMERO2=$_GET["num2"];
		
		if (isset($_GET["num3"]))
			{
		       $NUMERO3=$_GET["num3"];
			   
		if (isset($_GET["operacion"]))
			{
		       $OPERACION=$_GET["operacion"];	   
			   
		if(is_numeric($NUMERO1) && is_numeric($NUMERO2) && is_numeric($NUMERO3) && is_numeric($OPERACION))
	        { 
		
		
		
	   $uno= $NUMERO1;
	   $dos = $NUMERO2;
	   $tres= $NUMERO3;		
	   $maximo = max ($uno, $dos, $tres);
	   $minimo= min ($uno, $dos, $tres);


        if ($OPERACION == 1) 
		    {
			 echo "<b>"; echo "$uno";  echo"<sup>"; echo"$dos"; echo"</sup>"; echo" = "; echo "</b>"; echo pow($uno,$dos);
			} 
	    if ($OPERACION == 2) 
		    {
            echo"<b>";  echo "La raiz cuadrada de "; echo$tres; echo" es: "; echo"</b>"; echo sqrt ($tres);
            }
	    if ($OPERACION == 3) 
		    {
             echo"<b>"; echo "El máximo de los tres numeros "; echo "($uno, $dos, $tres)"; echo " es: "; echo"</b>"; ; echo $maximo;
		    }
		if($OPERACION == 4) 
		    {
			 echo"<b>"; echo "El minimo de los tres numeros "; echo "($uno, $dos, $tres)"; echo " es: "; echo"</b>"; echo $minimo;
		    }
		elseif($OPERACION == 5) 
		    {
              echo"<b>"; echo "Un numero aleatorio entre "; echo "$minimo y $maximo"; echo " es: "; echo"</b>"; $numeroaleatorio = rand ($minimo, $maximo); echo $numeroaleatorio;
            }  
			}
	          else
	          { 
	            echo "<b> El número ingresado no es valido </b>";  
	          } 
			  }
              } 
              } 
              }  

		
		?> 
		</center>
	 </body>
</html>	 
	
<html>
   <title>
      Funciones Cadena
   </title>
   <body bgcolor="Azure">
         <center>
	   <font face="Congenial Black" color="Navy" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Funciones cadena   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	  <center>
	  
	     <form method="Post">
		     <br> <br> 
		  Un mensaje: <input name= "Mensaje" size="50" type="text">
		     <br> <br> 
          <input value="Enviar" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
		</center>
	 	
	
	  <center>
	   <font face="Congenial Black" color="Navy" size="3"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="20"> 
			    <b>
                  Una funcion para manejo de cadenas   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	  
	 <?php
	 if (isset ($_POST["Mensaje"]))
	    {
	   
	     $Frase=$_POST["Mensaje"];
		
		 
	 
	  echo"Longuitud del texto es: ";
	     /*Devuelve el número de caracteres de una cadena*/
		  echo "<b>";  echo (strlen ($Frase)); echo"</b>"; 
		      echo"<br> <br>";
			  
	$SinInicio = ltrim($Frase); 	/*Elimina los espacios*/	
    $longitus1 = strlen ($SinInicio);  /* Devuelve el valor*/	
	
	    echo "Longuitud del texto sin espacios al inicio es: ";
		 /*Elimina los espacios en blanco que se encuentran al principio de una cadena */
	    echo "<b>";  echo $longitus1; echo "</b>";
		   echo"<br> <br>";
	  
	  $SinFinal = rtrim($Frase);
	  $longitus2 = strlen ($SinFinal);
	  
	  echo"Longuitud del texto sin espacios al final es: ";
	     /*Elimina los espacios en blanco que se encuentran al final de una cadena */
	    echo "<b>";  echo $longitus2; echo "</b>";
		    echo"<br> <br>";	  
	  
	  $Ambas = trim($Frase);
	  $longitus3 = strlen ($Ambas); 
	 
	  echo"Longuitud del texto sin espacios al inicio y al final es: ";
	    /*Elimina los espacios en blanco que se encuentran al principio y final de una cadena */
	     echo "<b>"; echo $longitus3; echo "</b>";
		    echo"<br> <br>";
	 
	 }
	 ?>

	 <center>
	   <font face="Congenial Black" color="Navy" size="3"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="20"> 
			    <b>
                  En base a la cadena sin espacios se tiene lo siguiente   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	 <?php
	 	 if (isset ($_POST["Mensaje"]))
	    {
	   
	     $Frase=$_POST["Mensaje"];
		
	 
	 echo"Remplazando espacios por: ";
	    /*Reemplaza una parte de las cadenas de texto por otra.*/
	       $frasesin = str_replace (" ", "--)", $Frase);
		   echo "<b>"; echo $frasesin; echo"</b>";
	       echo "<br> <br>";
		   
	  echo"Convirtiendo a Mayusculas: ";
	      /*Devuelve todos los caracteres alfabéticos convertidos a mayúsculas.*/
	     echo "<b>"; echo strtoupper ($Frase); echo"</b>";
		     echo"<br> <br>";
		
	  echo"Convirtiendo a minusculas: ";
	   /*Devuelve todos los caracteres alfabéticos convertidos a mayúsculas.*/
	     echo "<b>"; echo strtolower($Frase); echo"</b>";
		     echo"<br> <br>";
	   
			 
	  echo"Cambiando el primer caracter a mayuscula: ";
	     /* Devuelve en mayúscula solo el primer carácter de la cadena*/
	  	echo "<b>";  echo ucfirst ($Frase); echo "<b>"; 
		     echo"<br> <br>";
	  
	  echo"Cabiando la primer letra de cada palabra a mayuscula: ";
	     /*Devuelve con cada una de sus palabras con la primera letra en mayúsculas */
	  	 echo "<b>"; echo ucwords ($Frase); echo "<b>";
		     echo"<br> <br>";
	 
	 
     }
	 ?>
			   
	  
	</body>
</html>
<html>
  <title>
       Tabla Multiplicar
  </title>
   <body bgcolor ="MistyRose ">
      <center>
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Tabla de Multiplicar del número indicado 
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br>
	  <center>
	  	  <font face="Britannic Bold" color="Crimson" size="3">
	      <form method="Post">
		     <br> <br> 
		  Número de la Tabla de Multiplicar que quieres Generar: <br> <br> <input name= "Numero" size="5" type="text"> 
		     <br> <br>
          <input value="Generar Tabla" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
		  </form>
	    </font>
	  </center>
	  <center>
	  <?php
	   if(isset($_POST["Numero"]))
	      { 
			 $numero=$_POST["Numero"];
			 		   
	   if(is_numeric ($numero))
		   { 
			 	 			 		 
			for  ($a =1; $a <=10; $a=$a+1)
			{

		    echo"$a x $numero = ";  echo$a*$numero; echo"<br>";
			}
		   }
		    else 
			{
				echo "<b> El valor tecleado NO es valido, por lo que NO se puede generar la Tabla de Multiplicar </b>";
			   
		   }
		   }
	  ?>
	  </center>
	</body>
</html>

	  
<html>
  <title>
       Arreglos
  </title>
   <body bgcolor ="MistyRose ">
      <center>
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                  ARREGLO CON LLAVE TIPO CADENA  
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <center>
	  <br> <br>
	  <?php
	   $estudiante1['nombre']= "Lizbeth";
	   $estudiante1['num_cuenta']= 322032909;
	   $estudiante1['prom_global']= 8.90;
	   
	   $estudiante2['nombre']= "Alison";
	   $estudiante2['num_cuenta']= 323262448;
	   $estudiante2['prom_global']= 9.51; 

     echo"La alumna " ;  echo "<b>"; echo $estudiante1['nombre']; echo "</b>"; echo " con numero de cuenta "; echo "<b>"; echo $estudiante1['num_cuenta']; echo "</b>"; echo " tiene "; echo "<b>"; echo $estudiante1['prom_global']; echo "</b>"; echo" de promedio global"; 
     echo "<br>";	 
	 echo "<ul>";
	 foreach ($estudiante2 as $llave => $valor) 
	 {
	   echo "<li>"; echo "<i> $llave: </i>"; echo " <b> $valor </b>"; echo "</li>"; 
	 }
	 echo "</ul>";

	 ?>
	 </center>
	    
	  
	  <br> 
	  <br>
      <center>
	   <font face="Forte" color="Red" size="3"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="PeachPuff" width="600" height="20"> 
			    <b>
                  Arreglo con llave numerica  
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	  <?php
	  $unidades_curso [0] = "Creación de páginas WEB en lenguaje HTML";
	  $unidades_curso [1] = "Lenguaje de Programación para Aplicaciones WEB PHP"; 
      $unidades_curso [2] = "Base de Datos"; 
	  
	  echo "Lo primero que se debe aprender, es lo visto en "; echo"<b>"; echo $unidades_curso [0]; echo"</b>"; 
	  echo "<br> <br>";
	  echo "La Unidad de "; echo"<b>"; echo $unidades_curso [0]; echo"</b>"; echo" lo abordamos el semestre pasado";
      echo "<br> <br>";
	  echo "La Unidad de "; echo"<b>"; echo $unidades_curso [1]; echo"</b>"; echo " es lo que estamos tratando ahorira";
	  echo "<br> <br>";
	  echo "La Unidad de "; echo"<b>"; echo $unidades_curso [2]; echo"</b>"; echo " es la que abordaderemos al concluir la Unidad que estamos tratando"; 	  
	      echo "<br> <br>";	 
	 echo "<ul>";
	 foreach ($unidades_curso as $numero => $aprendizaje) 
	 {
	   echo "<li>"; echo "Lugar"; echo"<i> $numero: </i>"; echo "<b> $aprendizaje </b>"; echo "</li>"; 
	 }
	 echo "</ul>"; 
	  ?>
	 </center>
	<body>
</html>
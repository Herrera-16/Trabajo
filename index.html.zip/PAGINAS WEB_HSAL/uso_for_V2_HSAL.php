<html>
     <title>
	      Ejemplo For
	 </title>
    <body bgcolor ="MistyRose ">
	  <center>
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Ejemplo de Uso de For 
				</b>
             </marquee>
          </div>
       </font> 
	  <font face="Britannic Bold" color="Crimson" size="3">
	      <form method="Get">
		     <br> <br> 
		  Una Frase: <input name= "Frase" size="40" type="text"> 
		     <br> <br> 
		  El número de veces que se repetira la frase: <input name= "Veces" size="5" type="text"> 
		     <br> <br>
          <input value="Mostrar Frase" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
		  </form>
	 </font>
	 <?php
	  if(isset($_GET["Frase"]))
		   {
			 $FRASE=$_GET["Frase"];
			 
	  if(isset($_GET["Veces"]))
	      {
			 
			 $VECES=$_GET["Veces"];
			 		   
	   if(is_numeric($_GET["Veces"]))
		   { 
			 	 			 		 
			for  ($a = 1; $a <= $VECES; $a++)
			{

		    echo"$a.$FRASE <br>";
			}
		   }
		    else 
			{
				echo"Datos de repetición invalidos, favor de ingresar un dato valido (numerico)";
			   
		   }
		   }
		   }
		   
	 ?>
	  </center>
	</body>
</html>
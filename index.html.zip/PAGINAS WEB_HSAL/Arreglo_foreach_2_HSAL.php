 <html>
   <title>
       Foreach Llave y Valor
   </title>
   <body bgcolor="Azure">
         <center>
	   <font face="Congenial Black" color="Navy" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Muestra de llaves y valores de arreglos  
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	  <center>
	  <?php
	  $tienda ['niños'] = "pantalon";
	  $tienda ['damas'] = "blusa";
	  $tienda ['caballeros'] = "camisa"; 
	  $tienda ['bebes'] = "mameluco";   
	  
	 foreach ($tienda as $persona => $ropita)
	 {
       echo "El elemento"; echo"<i> $persona </i>"; echo"contiene"; echo" <b> $ropita </b> <br>";
	 }
	 	 echo "<br>";  
	 
	 $lineaBlanca [0] = "Refrigereador";
	 $lineaBlanca [1] = "Estufa";
	 $lineaBlanca [2] = "MicroOndas"; 
	 
	 
	 foreach ($lineaBlanca as $numero => $aparatos)
	 {
       echo "El elemento del <i> lugar </i>"; echo"<i> $numero </i>"; echo" contiene"; echo" <b> $aparatos </b> <br>";
	 }
	 
	  ?>
	  </center>
	  
   </body>
</html>
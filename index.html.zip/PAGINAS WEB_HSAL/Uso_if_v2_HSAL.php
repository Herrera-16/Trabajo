<html>
     <title>
	      Uso if-else
	 </title>
    <body bgcolor ="Honeydew">
	   <font face="DarkTurquoise" color="RoyalBlue" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="PaleTurquoise" width="600" height="25"> 
                   Ejemplo de uso de if - else 
             </marquee>
          </div>
       </font> 
	  <center>
	  <font face="Arial" color="DarkTurquoise" size="3">
	      <form method="Post">
	         <br> <br>
          Número de inasistencia del alumno: <input name= "Faltas" size="5" type="text">
		     <br> <br> 
		  Calificación Final del alumno: <input name= "C_Final" size="5" type="text">
		     <br> <br> 
          <input value="Enviar" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
	  </font>
	 <center>		 
	 <?php
	 $NumeroInasistencias=$_POST["Faltas"];
	 $CalificacionFinal= $_POST["C_Final"];
	 $Aprobada=6;
	 $FaltasPromedio=2;
	 
	 echo "Las inasistencias son: "; echo "<b>";  echo $NumeroInasistencias; echo "</b>"; echo "<br>"; echo "<br>"; 
	 echo "La calificación final es: "; echo "<b>";  echo $CalificacionFinal; echo "</b>"; echo "<br>"; echo "<br>"; 
	 if (($NumeroInasistencias <= $FaltasPromedio) && ($CalificacionFinal >= $Aprobada))                                                                          
	  { 
        echo "Como no se superan las inasistencias y la calificación final es"; echo"<br>"; echo"aprobatoria"; echo "<b>"; echo" el alumno aprueba"; echo "</b>"; 
	  }
	 
	 else 
	  {
	    echo "Como se tienen más de dos inasistencias o la calificación final es"; echo "<br>"; echo "reprobatoria"; echo "<b>"; echo " el alumno reprueba"; echo "</b>";
	  }
	 ?>
	 </center>
	 </body>                  
</html>    

<html>
    <head>
        <title>
              Nombre Variable    
        </title>
    </head>
    <body bgcolor ="Honeydew">
		<font face="Cooper Black" color="DarkTurquoise" size="3">
	<center> 	
       <form method="Post">
	         <br> <br>
          Nombre   <input name="Nombre" size="20" type="text"> 
	         <br> <br>
          <input value="Enviar" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
     <?php  

	   $NombrePersona= $_POST["Nombre"]; 
	   $Saludo= "Bienvenid@:"; 
	   
	   echo $Saludo; echo $NombrePersona;
     ?>	
	    </form>
    </center>	 
	  
	</body>
</html>
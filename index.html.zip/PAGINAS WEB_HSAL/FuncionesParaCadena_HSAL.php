<html>
     <title>
	      Funciones para cadenas
	 </title>
    <body bgcolor ="MistyRose ">
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Funciones para cadenas 
				</b>
             </marquee>
          </div>
       </font> 
	  <center>
	  <br>
	  <br>
	  
		 
	  <?php
	  
	  	 $frase="Pero si .... la etapa mas linda y con bonitos recuerdos es la prepa  _  aprendiendo mucho";
		 $frase2="La mirada nunca miente";
		 
	  
	  echo"<b> Función strlen </b>";
	     /*Devuelve el número de caracteres de una cadena*/
	   echo"<br>";
	    echo ("El numero de letras incluyendo espacios en blanco del texto es de: ");
	      echo(strlen($frase));
		   echo"<br> <br>";
	  
	  echo"<b> Función ltrim </b>";
	     /*Elimina los espacios en blanco que se encuentran al principio de una cadena */
	   echo"<br>";
	     echo(ltrim($frase));
		    echo"<br> <br>";
	  
	  echo"<b> Función rtrim </b>";
	     /*Elimina los espacios en blanco que se encuentran al final de una cadena */
	   echo"<br>";
	     echo(rtrim($frase));
		    echo"<br> <br>";	  
	  
	  echo"<b> Función trim </b>";
	    /*Elimina los espacios en blanco que se encuentran al principio y final de una cadena */
	   echo"<br>";
	     echo(trim($frase));
		    echo"<br> <br>";
	  
	  echo"<b> Función str_replace </b>";
	    /*Reemplaza una parte de las cadenas de texto por otra.*/
	   echo"<br>";
	     $resultado = str_replace ("recuerdos", "momentos de risa", $frase);
	       echo "<b>Frase original:</b> "; echo $frase;
		     echo "<br>";
		   echo "<b>Frase nueva:</b> "; echo $resultado;
		     echo"<br> <br>";
	  
	  echo"<b> Función strcmp </b>";
	    /*recibe dos cadenas y devuelve un entero. */
	   echo"<br>";
        $sentimiento = strcmp ($frase,$frase2);
		   echo $sentimiento; 
		      echo"<br> <br>";		   
	  
	  echo"<b> Función strtolower </b>";
	      /*Transforman una cadena de caracteres en la misma cadena en minúsculas o mayúsculas respectivamente.*/
	   echo"<br>";
         echo strtolower ($frase);		 
		 	 echo"<br> <br>";
			 
	  echo"<b> Función strtoupper </b>";
	      /*Devuelve todos los caracteres alfabéticos convertidos a mayúsculas.*/
	    echo"<br>";
	     echo strtoupper ($frase);
		     echo"<br> <br>";
	  
	  echo"<b> Función ucfirst </b>";
	     /* Devuelve en mayúscula solo el primer carácter de la cadena*/
	   echo"<br>";
	  	 echo ucfirst ($frase);
		     echo"<br> <br>";
	  
	  echo"<b> Función ucwords </b>";
	     /*Devuelve con cada una de sus palabras con la primera letra en mayúsculas */
	   echo"<br>";
	  	 echo ucwords ($frase);
		     echo"<br> <br>";
	  
	  	 ?>
	 </form>
	 </center>
	</body>
</html>
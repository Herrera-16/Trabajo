<html>
  <title>
        Operadores Aritmeticos
  </title>
  <body bgcolor="AntiqueWhite">
     <font face="Britannic Bold" color="Bisque" size="4">
        <center>
           <marquee direction="right" bgcolor="SandyBrown" height="30">   
                 Uso de Variables y Operadores Aritmeticos
           </marquee>
        </center>
     </font>
	 <?php
	 $x=45;
	 $y=19;
	 echo"<center>";
	 echo "<br>";
	 echo "$x + $y = ";  echo $x + $y;
	 echo"<br>";
	 echo "$x - $y = ";  echo $x - $y;
	 echo"<br>";
	 echo "$x * $y = ";  echo $x * $y;
	 echo"<br>";
	 echo "$x / $y = ";  echo $x / $y;
	 echo"<br>";
	 echo "$x % $y = ";  echo $x % $y;
	 echo"</center>";
	 ?> 
  </body>
</html>
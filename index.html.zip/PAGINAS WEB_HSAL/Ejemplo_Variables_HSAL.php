<html>
     <title>
           Ejercicio Variables 
     </title>
     <body bgcolor="MistyRose">
	     <?php
		 $nombre1="Lizbeth";
		 $_4lugar="Monterey";
		 $numerohermanos=1;
		 $preciorefresco=16.50;
		 $mujer=True;
		 
		 echo$nombre1;
		  //*muestra el contenido de la variable en este caso es Lizbeth*//
		   echo "<br>"; 
		   echo "<br>";
		 echo "Estado de la Republica:"; echo$_4lugar;
		   echo "<br>";
		   echo "<br>";
		 echo"Numero de hermanos:"; echo $numerohermanos;
		   echo "<br>";
		   echo "<br>";
		 echo"Precio del refresco:"; echo$preciorefresco;
	       echo "<br>";
		   echo "<br>";
		 echo"¿Soy mujer?"; echo$mujer;
		 ?>
     </body>
</html>
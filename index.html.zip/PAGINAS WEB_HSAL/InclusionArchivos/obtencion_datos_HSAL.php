
<?php
 include ("Encabezado_HSAL.html");
?>


		
    <center>
     <table> <tr> <td bgcolor="LightCyan">
    	<?php
	  
	  if (isset($_POST["nombre"]))
		{
		  $NombrePersona=$_POST["nombre"];
		  
	  if (isset($_POST["edad"]))	
		{  
	      $Edades=$_POST["edad"];
  
	  if (isset($_POST ["direccion"]))
		{
	      $Direccionn=$_POST["direccion"];
		  
	  if (isset($_POST["telefono"]))
		{
	      $telefonos=$_POST["telefono"];
	
      $Informacion ["Nombre: "] = $NombrePersona;	
	  $Informacion ["Edad: "] = $Edades;
	  $Informacion ["Dirección: "] = $Direccionn;
	  $Informacion ["Telefono: "] = $telefonos;
	   
		foreach ($Informacion as $valor => $contenido)
		  {
		$primermayuscula= ucfirst ($valor);
		$todomayuscula =strtoupper ($contenido);
		
		echo  "<b> $primermayuscula </b>  $todomayuscula  <br>";
	      }
		}
		}
		}
		}

	  ?>
	  </td> </tr>
	  </table>
	 </center>

 <?php
   include ("Pie_HSAL.html");
 ?>

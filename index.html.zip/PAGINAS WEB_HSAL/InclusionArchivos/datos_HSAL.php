
<?php
 include ("Encabezado_HSAL.html");
?>



    <center>
      <table>
         <form method="post" action="obtencion_datos_HSAL.php">
		          <tr> <td> <b> Nombre: </b> <br> <br>  </td> <td> <input name = "nombre" size= "30" type= "text"> <br> <br> </td> </tr>
				  <tr> <td> <b> Edad: </b> <br> <br> </td> <td> <input name = "edad" size= "5" type = "text"> <br> <br> </td> </tr>
				  <tr> <td> <b> Dirección: </b> <br> <br> </td> <td> <input name = "direccion" size= "100" type = "text"> <br> <br> </td> </tr>
				  <tr> <td> <b> Teléfono: </b> <br> <br> </td> <td> <input name = "telefono" size= "10" type = "text"> <br> <br> </td> </tr>
				  <tr> <td> </td> <td> <input value="Enviar" type="submit">  <input value="Limpiar" type="reset"> <br> <br> </td> </tr> 
	  </table>
	</center>
  
 <?php
   include ("Pie_HSAL.html");
 ?>
<html>
   <title>
      Arreglo alimentos
   </title>
   <body bgcolor="Azure">
         <center>
	   <font face="Congenial Black" color="Navy" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Alimentos del dia   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	  <center>
	  
	  <?php
	  
	  
	  $alimento["Desayuno"] = "Jugo de naranja";
	  $alimento["Colacion1"] = "Barra de granola";	  
	  $alimento["Comida"] = "Enchiladas verdes";
	  $alimento["Colacion2"] = "Fruta";
	  $alimento["Cena"] = "Te con un pan";	  
	  
	 foreach ($alimento as $momentos => $Alimentacion)
	 {
	  echo "<table border =2 bordercolor=DarkBlue>";
       echo "<tr> <th bgcolor=LightCyan height=50 width=100> <center> $momentos </center> </th> <td bgcolor=Plum height=50 width=150> <center> $Alimentacion </center> </td> </tr>";;
	 }	   

	  ?>
  </table>
	  </center>
	</body>
</html>
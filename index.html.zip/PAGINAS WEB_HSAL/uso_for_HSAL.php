<html>
  <title>
  
  </title>
   <body bgcolor ="MistyRose ">
      <center>
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Ejemplo uso Ciclo For
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br>
	  
	  <?php 
	  $i=1;
	  $a=3;
	  $c=8;
	    for ($i = 1; $i <= 25; $i++) {
			echo $i;
			echo "<br/>";
		}
		echo "<br/>";
		echo "<br/>";
		for ($a = 3; $a <= 30; $a=$a+3) {
			echo $a;
			echo "<br/>";
		}
		echo "<br/>";
		echo "<br/>";
		for ($a = 7; $a < 150; $a=$a*2) {
			echo $a;
			echo "<br/>";
		}
		
		
	  ?>
  </body>
</html>

<html>
   <title>
      Funciones Matematicas
   </title>
   <body bgcolor="Azure">
         <center>
	   <font face="Congenial Black" color="Navy" size="4"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Uso de funciones matemáticas   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br>
	  <center>
	  
	     <form method="GET">
		     <br> <br> 
		  Un primer número: <input name= "num1" size="5" type="text">
		     <br> <br> 
		  Un segundo número: <input name= "num2" size="5" type="text">
		     <br> <br>
		  Un tercer número: <input name= "num3" size="5" type="text">
		     <br> <br>		 
          <input value="Muestra Resultados" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
		 </form>
		</center>
		
	   <font face="Congenial Black" color="Navy" size="3"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="20"> 
			    <b>
                  ********************* Resultados *********************    
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> 		
	  <center>
		<?php
		 if (isset($_GET["num1"]))
	       { 	          
		       $NUMERO1=$_GET["num1"];
				  			  
		if (isset($_GET["num2"]))
			{
		       $NUMERO2=$_GET["num2"];
		
		if (isset($_GET["num3"]))
			{
		       $NUMERO3=$_GET["num3"];
			   
		 if(is_numeric($NUMERO1) && is_numeric($NUMERO2) && is_numeric($NUMERO3))
	        { 
		
	    $numeros= array ($NUMERO1, $NUMERO2, $NUMERO3);
		
	  echo "<b>"; echo "$NUMERO1";  echo"<sup>"; echo"$NUMERO2"; echo"</sup>"; echo"= "; echo "</b>"; echo pow($NUMERO1,$NUMERO2);
	  echo "<br> <br>";
      echo"<b>";  echo "La raiz cuadrada de "; echo$NUMERO3; echo" es: "; echo"</b>"; echo sqrt ($NUMERO3);
	    echo"<br> <br>";
	  echo"<b>"; echo "El máximo de los tres numeros "; echo "($NUMERO1, $NUMERO2, $NUMERO3)"; echo " es: "; echo"</b>"; $maximo = max ($numeros); echo $maximo;
	    echo"<br> <br>";
	  echo"<b>"; echo "El minimo de los tres numeros "; echo "($NUMERO1, $NUMERO2, $NUMERO3)"; echo " es: "; echo"</b>"; $minimo= min ($numeros); echo $minimo;
	    echo"<br> <br>";
	  echo"<b>"; echo "Un numero aleatorio entre "; echo "$minimo y $maximo"; echo " es: "; echo"</b>"; $numeroaleatorio = rand ($minimo, $maximo); echo $numeroaleatorio; 
		  } 	   
	   
	 else
	 { 
	     echo "<b> El número ingresado no es valido </b>";  
	 }      
	 }
	 }
	 }
		
		?> 
		</center>
	 </body>
</html>	 
	
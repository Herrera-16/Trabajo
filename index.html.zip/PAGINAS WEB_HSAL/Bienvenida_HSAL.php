<html>
     <title>
           Bienvenida 
     </title>
     <body bgcolor="MistyRose">
        <font face="Britannic Bold" color="Crimson" size="4">
		   <?php 
		      echo  "¡Hola!"; 
			   echo "<br>";
			  echo  "¡¡¡ Bienvenid@ a mi primer pagina con PHP !!!";
			    echo"<br>";
			  echo  "*****Cuidate Mucho*****"; 
			    echo "<br>";
			  echo  8+8;		  		  
		   ?> 
		</font>
     </body>
</html>
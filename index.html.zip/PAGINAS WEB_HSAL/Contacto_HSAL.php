<html>
    <head>
        <title>
              Contacto   
        </title>
    </head>
    <body bgcolor ="Honeydew">
		<font face="Cooper Black" color="DarkTurquoise" size="3">
	<center> 	
       <form method="Get" action="MuestraDatosContactos_HSAL.php">
	         <br> <br>
          Nombre: <input name="contacto_name" size="40" type="text"> 
	         <br> <br>
		  Email: <input name="contacto_email" size="30" type="text">
		     <br> <br>
	      Mensaje: <textarea name="contacto_mensaje"  cols= "40" rows="5"> </textarea>
		     <br> <br> 
          <input value="Enviar" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
	    </form>
    </center>	 
	  
	</body>
</html>
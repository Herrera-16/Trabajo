<html>
     <title>
           Datos Personales 
     </title>
     <body bgcolor="MistyRose">
	  <center>
	   <Marquee direction "left" bgcolor = "PeachPuff " width= "500" height= "25">
        <font face="Britannic Bold" color="Tomato " size="4">
          Mis Datos 
		</font>
       </marquee>
	  </center>
	     <?php
		  echo "<center>";
		  echo "<br>";
		 echo  "<b>"; echo "Nombre:"; echo "</b>"; echo  "America Lizbeth Herrera Sanchez";
		  echo "<br>";
		 echo "<b>"; echo "Fecha de nacimiento:"; echo "</b>"; echo "16 de agosto";
		  echo "<br>";
		 echo "<b>"; echo "Hobies:"; echo "</b>"; echo "Escuchar musica, salir a caminar, ver los atardceres";
         echo "<br>";	
         echo date ('d/m/Y');
           //Muestra la informacionn representada en forma de fecha del dia de hoy con el formato ('d/m/Y')		 
		  echo "</center>";
		 ?>
     </body>
</html>
	 
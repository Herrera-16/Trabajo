<html>
  <title>
        Variables Comillas 
  </title>
  <body bgcolor="AntiqueWhite">
     <font face="Goudy Stout" color="Bisque" size="4">
        <center>
           <marquee direction="right" bgcolor="SandyBrown" height="30">   
                 Variable y Comillas
           </marquee>
        </center>
     </font>
	 <?php
	   $Platillo1="Enchiladas verdes";
	   $Platillo2="Ensalada Rusa";
	   $Platillo3="Pechuga rellena empanizada";
	   //Sale el nombre de la variable
	   echo'Mis platilllos favorios son: $Platillo1,$Platillo2, $Platillo3';
	   echo'<br>';
	   echo'<br>';
	   //Sale el valor que tiene la variable
	   echo"Mis platillos Favoritos son: $Platillo1,$Platillo2, $Platillo3";
	   echo"<br>";
	   echo"<br>";
	   //Sale el valor asignado a la variable
	   echo$Platillo2;
	 ?>    
  </body>
</html>
<html>
  <head>
   <title>
      Funciones Fecha
   </title>
  </head>
   <body bgcolor="Azure">
      <center>
	   <font face="Congenial Black" color="Navy" size="4"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Trabajo con Funciones de fecha   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>  
	  <?php
	    echo "<b> Zona horarica predeterminada : </b>"; 
		echo "<b> Zona Horarica correspondiente a Ciudad de Mexico  lo cual se establecio para lo siguiente </b>";
        $fecha_actual = date ('Y-m-d H:i:s');
           echo $fecha_actual;
		
	  ?>
	 <center>
	   <font face="Congenial Black" color="Navy" size="4"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Trabajo con Funciones de fecha   
				</b>
             </marquee>
          </div>
       </font> 
	  </center>  
	  <?php
	    $fecha ['seconds'] = date ("s");
		$fecha ['minutes'] = date ("i");
		$fecha ['hours'] = date ("h");
		$fecha ['mday'] = date ("md");
		$fecha ['wday'] = date ("w"); 
		$fecha ['mon'] = date ("j");
		$fecha ['year'] = date ("Y");
		$fecha ['yday'] = date ("d");
		$fecha ['weekday'] = date ("l");
		$fecha ['month'] = date ("F");
		$fecha [0] = date ("u"); 
	 foreach ($fecha as $valor => $representan)
	 {
        echo"$representan"; echo"<b> $valor : </b>";  echo "<br>";
	 }		
	  ?>
	  
  </body>
</html>
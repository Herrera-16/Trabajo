<html>
   <title>
       Foreach Valor
   </title>
   <body bgcolor="Azure">
         <center>
	   <font face="Congenial Black" color="Navy" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="LightSkyBlue" width="600" height="25"> 
			    <b>
                  Muestra de valores de arreglos  
				</b>
             </marquee>
          </div>
       </font> 
	  </center>
	  <br> <br>
	  <center>
	  <?php
	  $tienda ['niños'] = "pantalon";
	  $tienda ['damas'] = "blusa";
	  $tienda ['caballeros'] = "camisa"; 
	  $tienda ['bebes'] = "mameluco";   
	  
	 foreach ($tienda as $ropita)
	 {
       echo "<br> $ropita";
	 }
	 	 echo "<br>";  
	 
	 $lineaBlanca [0] = "Refrigereador";
	 $lineaBlanca [1] = "Estufa";
	 $lineaBlanca [2] = "MicroOndas"; 
	 
	 
	 foreach ($lineaBlanca as $aparatos)
	 {
       echo "<br> $aparatos";
	 }
	 
	  ?>
	  </center>
	 
	  
   </body>
</html>

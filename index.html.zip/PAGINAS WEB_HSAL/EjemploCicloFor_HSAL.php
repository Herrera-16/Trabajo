<html>
  <title>
  
  </title>
   <body bgcolor ="MistyRose ">
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Ejemplo uso Ciclo For
				</b>
             </marquee>
          </div>
       </font> 
	  <center>
	  <br>
	  
	  <?php 
	  $i=1;
	    for ($i = 1; $i <= 25; $i++) {
			echo $i;
			echo "<br/>";
		}
	  ?>
  </body>
</html>

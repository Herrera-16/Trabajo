<html>
     <title>
	      Uso if-else
	 </title>
    <body bgcolor ="Honeydew">
	   <font face="DarkTurquoise" color="RoyalBlue" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="PaleTurquoise" width="600" height="25"> 
                   Ejemplo de uso de if - elseif 
             </marquee>
          </div>
       </font> 
	  <center>
	  <font face="Arial" color="DarkTurquoise" size="3">
	      <form method="Post">
		     <br> <br> 
		  Número Entero: <input name= "Numero" size="5" type="text">
		     <br> <br> 
          <input value="Enviar" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
	 </center>	
	</body>
	<center>
	<?php
	$NumeroResivido=$_POST["Numero"];
	$Positivo=1;
	$Negativo=-1;
	$Cero=0;
	  echo "El valor de la variable es:"; echo "<b>";  echo $NumeroResivido; echo "</b>";
	  echo "<br>"; echo "<br>"; 
	    if ($NumeroResivido >= $Positivo)
		{ 
	     echo "Por lo tanto es"; echo "<b>"; echo" positivo"; echo "</b>"; 
		}
	  
	    elseif ($NumeroResivido <= $Negativo)
		{ 
		 echo "Por lo tanto es"; echo "<b>"; echo" negativo"; echo "</b>"; 
		}
	  
	        else
		    { 
		     echo "Por lo tanto es"; echo "<b>"; echo" cero"; echo "</b>"; 
		    }
	?>
	</center>
			 </font> 

</html>
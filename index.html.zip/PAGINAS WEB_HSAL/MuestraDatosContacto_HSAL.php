<html>
    <head>
        <title>
              Datos Contacto    
        </title>
    </head>
    <body bgcolor ="Honeydew">
	   <font face="DarkTurquoise" color="PaleGreen" size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Plum" width="600" height="25"> 
                   Los Datos Enviados Fueron 
             </marquee>
          </div>
       </font> 
	</body>
	<center>
	<?php
	  $NombrePersona=$_GET["contacto_nombre"];
	  $Contacto=$_GET["contacto_email"];
	  $Mensaje=$_GET["contacto_mensaje"];
	  
	  echo  $NombrePersona; 
	     echo "<br>";
		 echo "<br>";
	  echo  $Contacto; 
	     echo "<br>";
		 echo "<br>";
	  echo $Mensaje;	  	  
	?>
	</center>
</html>
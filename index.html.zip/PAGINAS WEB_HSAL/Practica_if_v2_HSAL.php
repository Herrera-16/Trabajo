<html>
     <title>
	      Clasificacion
	 </title>
    <body bgcolor ="MistyRose ">
	   <font face="Congenial Black" color="PeachPuff " size="5"> 
          <div align= "center"> 
             <marquee direction= "left" bgcolor="Crimson" width="600" height="25"> 
			    <b>
                   Clasificación segun el año de nacimiento
				</b>
             </marquee>
          </div>
       </font> 
	  <center>
	  <font face="Britannic Bold" color="Crimson" size="3">
	      <form method="Post">
		     <br> <br> 
		  Nombre: <input name= "nombre" size="30" type="text"> 
		     <br> <br> 
		  Año de Nacimiento: <input name= "nacimiento" size="5" type="text"> 
		     <br> <br> 
          <input value="Mayor o menor" type="submit"> <input value="Borrar" type="reset"> 
			 <br> <br> 
	 	
	 <?php
	   if(isset($_POST["nombre"]))
		   {
			 $NOMBRE=$_POST["nombre"];
		   
	   if(isset($_POST["nacimiento"]))
		   {
			 $NACIMIENTO=$_POST["nacimiento"];
		   
		 if(is_numeric($NACIMIENTO))
			 {
				if($NACIMIENTO<=1974)
			      {
			          echo"$NOMBRE eres un adulto mayor"; 
		          }
				  elseif($NACIMIENTO<=2006)
			      {
			          echo"$NOMBRE eres un adulto"; 
		          }
				  elseif($NACIMIENTO>=2012)
			      {
			          echo"$NOMBRE eres un niño"; 
		          }
				  elseif($NACIMIENTO>=2007)
			      {
			          echo"$NOMBRE eres un adolecente"; 
		          }
				  else
			      {
			          echo"$NOMBRE eres un niño"; 
		          }
				  
				  }
		          else
			      {
			          echo"Eror dato no valido"; 
		          }
				  }
				  }
	 ?>
	 </form>
	 </center>
	</body>
</html>
					
			